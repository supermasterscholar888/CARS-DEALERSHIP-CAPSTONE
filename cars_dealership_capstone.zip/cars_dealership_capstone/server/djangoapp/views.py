from django.contrib.auth import authenticate, login, logout
from django.contrib.auth.models import User
from django.views.decorators.csrf import csrf_exempt
from django.utils.decorators import method_decorator
from rest_framework import status
from rest_framework.decorators import api_view, permission_classes
from rest_framework.permissions import AllowAny
from rest_framework.response import Response
from .models import Dealer, Review
from .serializers import DealerSerializer, ReviewSerializer

@api_view(["GET"])
@permission_classes([AllowAny])
def dealers(request):
    queryset = Dealer.objects.all()
    state = request.query_params.get("state")
    if state:
        queryset = queryset.filter(state__iexact=state)
    return Response(DealerSerializer(queryset, many=True).data)

@api_view(["GET"])
@permission_classes([AllowAny])
def dealer_detail(request, dealer_id):
    try:
        dealer = Dealer.objects.get(pk=dealer_id)
    except Dealer.DoesNotExist:
        return Response({"error": "Dealer not found"}, status=404)
    return Response(DealerSerializer(dealer).data)

@api_view(["GET"])
@permission_classes([AllowAny])
def dealer_reviews(request, dealer_id):
    if not Dealer.objects.filter(pk=dealer_id).exists():
        return Response({"error": "Dealer not found"}, status=404)
    reviews = Review.objects.filter(dealer_id=dealer_id).order_by("-created_at")
    return Response(ReviewSerializer(reviews, many=True).data)

@api_view(["POST"])
def create_review(request):
    serializer = ReviewSerializer(data=request.data)
    if not serializer.is_valid():
        return Response(serializer.errors, status=400)
    if not Dealer.objects.filter(pk=serializer.validated_data["dealer"].id).exists():
        return Response({"error": "Dealer not found"}, status=404)
    text = serializer.validated_data.get("review", "").lower()
    positive = ["fantastic", "great", "excellent", "good", "helpful", "wonderful", "amazing"]
    negative = ["bad", "poor", "terrible", "awful", "rude", "slow", "horrible"]
    sentiment = "positive" if any(w in text for w in positive) else (
        "negative" if any(w in text for w in negative) else "neutral")
    review = serializer.save(sentiment=sentiment)
    return Response(ReviewSerializer(review).data, status=201)

@api_view(["POST"])
@permission_classes([AllowAny])
def analyze_review(request):
    text = str(request.data.get("review", "")).lower()
    if not text.strip():
        return Response({"error": "review is required"}, status=400)
    positive = ["fantastic", "great", "excellent", "good", "helpful", "wonderful", "amazing"]
    negative = ["bad", "poor", "terrible", "awful", "rude", "slow", "horrible"]
    sentiment = "positive" if any(w in text for w in positive) else (
        "negative" if any(w in text for w in negative) else "neutral")
    return Response({"review": request.data.get("review"), "sentiment": sentiment})

@api_view(["POST"])
@permission_classes([AllowAny])
def login_user(request):
    username = request.data.get("username", "")
    password = request.data.get("password", "")
    user = authenticate(request, username=username, password=password)
    if user is None:
        return Response({"error": "Invalid username or password"}, status=400)
    login(request, user)
    return Response({"message": "Login successful", "username": user.username})

@api_view(["POST"])
def logout_user(request):
    logout(request)
    return Response({"message": "Logout successful"})
