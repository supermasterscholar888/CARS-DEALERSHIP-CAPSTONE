from django.urls import path
from . import views

urlpatterns = [
    path("dealers/", views.dealers, name="dealers"),
    path("dealers/<int:dealer_id>/", views.dealer_detail, name="dealer-detail"),
    path("dealers/<int:dealer_id>/reviews/", views.dealer_reviews, name="dealer-reviews"),
    path("reviews/", views.create_review, name="create-review"),
    path("analyze_review/", views.analyze_review, name="analyze-review"),
    path("login/", views.login_user, name="login"),
    path("logout/", views.logout_user, name="logout"),
]
