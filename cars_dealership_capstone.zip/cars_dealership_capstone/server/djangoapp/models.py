from django.db import models
from django.contrib.auth.models import User

class Dealer(models.Model):
    full_name = models.CharField(max_length=160)
    short_name = models.CharField(max_length=80, blank=True)
    city = models.CharField(max_length=100)
    state = models.CharField(max_length=80)
    address = models.CharField(max_length=255, blank=True)
    zip = models.CharField(max_length=15, blank=True)
    phone = models.CharField(max_length=40, blank=True)
    website = models.URLField(blank=True)
    class Meta:
        ordering = ["state", "city", "full_name"]
    def __str__(self):
        return self.full_name

class Review(models.Model):
    dealer = models.ForeignKey(Dealer, related_name="reviews", on_delete=models.CASCADE)
    name = models.CharField(max_length=120)
    purchase = models.BooleanField(default=False)
    car_make = models.CharField(max_length=80, blank=True)
    car_model = models.CharField(max_length=80, blank=True)
    dealership = models.CharField(max_length=160, blank=True)
    review = models.TextField()
    sentiment = models.CharField(max_length=30, blank=True)
    created_at = models.DateTimeField(auto_now_add=True)
    def __str__(self):
        return f"{self.dealer} review by {self.name}"
