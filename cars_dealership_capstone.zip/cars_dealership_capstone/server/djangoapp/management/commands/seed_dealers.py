from django.core.management.base import BaseCommand
from djangoapp.models import Dealer

SAMPLE_DEALERS = [
    {"full_name":"Kansas City Auto Mall","short_name":"KC Auto Mall","city":"Kansas City","state":"Kansas","address":"100 Main St","zip":"66101","phone":"555-0101"},
    {"full_name":"Wichita Motors","short_name":"Wichita Motors","city":"Wichita","state":"Kansas","address":"200 Market Ave","zip":"67202","phone":"555-0102"},
    {"full_name":"Dallas Car Center","short_name":"Dallas Cars","city":"Dallas","state":"Texas","address":"300 Elm St","zip":"75201","phone":"555-0103"},
    {"full_name":"Denver Auto Group","short_name":"Denver Auto","city":"Denver","state":"Colorado","address":"400 Park Ave","zip":"80202","phone":"555-0104"},
]
class Command(BaseCommand):
    help = "Create sample dealers for local testing"
    def handle(self, *args, **options):
        for item in SAMPLE_DEALERS:
            Dealer.objects.get_or_create(full_name=item["full_name"], defaults=item)
        self.stdout.write(self.style.SUCCESS("Sample dealers seeded."))
