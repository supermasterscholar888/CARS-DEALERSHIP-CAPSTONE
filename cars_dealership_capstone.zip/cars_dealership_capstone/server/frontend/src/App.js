import React, { useEffect, useState } from 'react';

const API = process.env.REACT_APP_API_URL || 'http://127.0.0.1:8000/djangoapp';

export default function App() {
  const [dealers, setDealers] = useState([]);
  const [state, setState] = useState('');
  const [selected, setSelected] = useState(null);
  const [reviews, setReviews] = useState([]);
  const [username, setUsername] = useState('');
  const [password, setPassword] = useState('');
  const [loggedIn, setLoggedIn] = useState('');
  const [review, setReview] = useState({name:'', purchase:false, car_make:'', car_model:'', review:''});
  const [message, setMessage] = useState('');

  async function loadDealers() {
    const url = state ? `${API}/dealers/?state=${encodeURIComponent(state)}` : `${API}/dealers/`;
    const res = await fetch(url);
    const data = await res.json();
    setDealers(Array.isArray(data) ? data : []);
  }
  async function openDealer(dealer) {
    setSelected(dealer);
    const res = await fetch(`${API}/dealers/${dealer.id}/reviews/`);
    const data = await res.json();
    setReviews(Array.isArray(data) ? data : []);
  }
  useEffect(() => { loadDealers().catch(() => setMessage('Could not load dealers. Is Django running?')); }, [state]); // eslint-disable-line
  async function doLogin(e) {
    e.preventDefault();
    const res = await fetch(`${API}/login/`, {
      method:'POST', headers:{'Content-Type':'application/json'},
      credentials:'include', body:JSON.stringify({username,password})
    });
    const data = await res.json();
    setMessage(data.message || data.error);
    if (res.ok) setLoggedIn(data.username);
  }
  async function submitReview(e) {
    e.preventDefault();
    if (!selected) return;
    const res = await fetch(`${API}/reviews/`, {
      method:'POST', headers:{'Content-Type':'application/json'},
      credentials:'include',
      body:JSON.stringify({...review, dealer:selected.id, dealership:selected.full_name})
    });
    const data = await res.json();
    if (!res.ok) { setMessage(JSON.stringify(data)); return; }
    setMessage('Review posted.');
    setReview({name:'',purchase:false,car_make:'',car_model:'',review:''});
    openDealer(selected);
  }
  async function doLogout() {
    const res = await fetch(`${API}/logout/`, {method:'POST', credentials:'include'});
    const data = await res.json();
    setLoggedIn('');
    setMessage(data.message);
  }

  return <main className="container">
    <header className="hero">
      <nav><a href="#home" className="brand">Drive<span>Review</span></a><div><a href="#about">About Us</a><a href="#contact">Contact</a></div></nav>
      <section className="hero-copy"><p className="eyebrow">FIND YOUR NEXT DRIVE</p><h1>Trusted dealers.<br/><span>Real experiences.</span></h1><p>Explore dealership locations and read honest customer reviews.</p></section>
    </header>
    <section className="toolbar">
      <div><h2>Dealerships</h2><p>Browse our dealer network across the United States.</p></div>
      <select value={state} onChange={e=>setState(e.target.value)}><option value="">All states</option><option>Kansas</option><option>Texas</option><option>Colorado</option></select>
    </section>
    {message && <p className="message">{message}</p>}
    <section className="dealer-grid">
      {dealers.map(d=><article className="dealer-card" key={d.id}>
        <img src={`https://images.unsplash.com/photo-1486406146926-c627a92ad1ab?auto=format&fit=crop&w=900&q=80`} alt="Dealership building"/>
        <div className="card-body"><span className="state">{d.state}</span><h3>{d.full_name}</h3><p>{d.city}, {d.state}</p><p>{d.address}</p><p>{d.phone}</p><button onClick={()=>openDealer(d)}>View dealer &amp; reviews</button>{loggedIn && <button className="secondary" onClick={()=>openDealer(d)}>Review Dealer</button>}</div>
      </article>)}
    </section>
    {selected && <section className="panel" id="dealer-detail">
      <button className="close" onClick={()=>setSelected(null)}>Close</button>
      <p className="eyebrow">DEALER DETAILS</p><h2>{selected.full_name}</h2><p>{selected.address}, {selected.city}, {selected.state} {selected.zip}</p><p>{selected.phone}</p>
      <h3>Customer reviews</h3>
      {reviews.length ? reviews.map(r=><article className="review" key={r.id}><strong>{r.name}</strong><span>{r.sentiment}</span><p>{r.review}</p></article>) : <p>No reviews yet.</p>}
      <h3>Post a review</h3>
      <form onSubmit={submitReview} className="review-form">
        <input required placeholder="Your name" value={review.name} onChange={e=>setReview({...review,name:e.target.value})}/>
        <input placeholder="Car make" value={review.car_make} onChange={e=>setReview({...review,car_make:e.target.value})}/>
        <input placeholder="Car model" value={review.car_model} onChange={e=>setReview({...review,car_model:e.target.value})}/>
        <textarea required placeholder="Write your review" value={review.review} onChange={e=>setReview({...review,review:e.target.value})}/>
        <label><input type="checkbox" checked={review.purchase} onChange={e=>setReview({...review,purchase:e.target.checked})}/> I purchased a vehicle here</label>
        <button type="submit">Submit review</button>
      </form>
    </section>}
    <section className="auth panel"><h2>{loggedIn ? `Signed in as ${loggedIn}` : 'Customer login'}</h2>
      {loggedIn ? <button onClick={doLogout}>Log out</button> : <form onSubmit={doLogin} className="login-form"><input placeholder="Username" value={username} onChange={e=>setUsername(e.target.value)} required/><input type="password" placeholder="Password" value={password} onChange={e=>setPassword(e.target.value)} required/><button>Log in</button></form>}
    </section>
    <section id="about" className="footer-info"><h2>About Us</h2><p>We help drivers discover dealerships and make informed decisions through customer feedback.</p><div className="team"><div><img src="https://images.unsplash.com/photo-1500648767791-00dcc994a43e?auto=format&fit=crop&w=300&q=80" alt="Alex Morgan"/><b>Alex Morgan</b><p>Customer Experience Lead</p><a href="mailto:alex@example.com">alex@example.com</a></div><div><img src="https://images.unsplash.com/photo-1494790108377-be9c29b29330?auto=format&fit=crop&w=300&q=80" alt="Jamie Lee"/><b>Jamie Lee</b><p>Dealer Relations Manager</p><a href="mailto:jamie@example.com">jamie@example.com</a></div></div></section>
    <section id="contact" className="footer-info"><h2>Contact Us</h2><p>Email: support@example.com · Phone: +1 (800) 555-0100</p></section>
    <footer>© {new Date().getFullYear()} DriveReview · Cars Dealership Capstone</footer>
  </main>;
}
